﻿app.controller('homeController', function ($scope) {

    $scope.msg = "Home!";
});